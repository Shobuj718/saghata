<?php include_once '../includes/header.php'; ?>



<div class="col-md-12">

    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <label for="" style="font-size: 22px;color: green;">Student Mark Updated Successfully</label> <br>
                <a class="btn btn-primary" href="view/admin/marksheet/markUpdateform.php"> Back </a>
            </div>
        </div>
    </div>
    
</div>







<?php include_once '../includes/footer.php'; ?>
